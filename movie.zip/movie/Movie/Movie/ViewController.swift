//
//  ViewController.swift
//  Movie
//
//  Created by swa on 2021/06/08.
//

import UIKit

class ViewController: UITableViewController {

    lazy var list : [MovieInfo] = {
        var datalist = [MovieInfo]()
        
        return datalist
    }()
    func callMovieAPI() {
        let url = "http://115.68.183.178:2029/hoppin/movies?version=1&page=\(self.page)&count=20&genreId=&order=releasedateasc"
        let apiURI : URL! = URL(string: url)
        let apidata = try! Data(contentsOf: apiURI)
        let log = NSString(data: apidata, encoding: String.Encoding.utf8.rawValue)
        NSLog("API Result=\( log )")
    
        do {
            let apiDictionary = try JSONSerialization.jsonObject(with: apidata, options: []) as! NSDictionary
            let hoppin = apiDictionary["hoppin"] as! NSDictionary
            let movies = hoppin["movies"] as! NSDictionary
            let movie = movies["movie"] as! NSArray
            
            for row in movie{
                let r = row as! NSDictionary
                let mvinfo = MovieInfo()
                
                mvinfo.title = r["title"] as? String
                mvinfo.descreiption = r["genreNames"] as? String
                mvinfo.thumbnail = r["thumbnailImage"] as? String
                mvinfo.detail = r["linkUrl"] as? String
                mvinfo.ratitng = Float(((r["ratingAverage"] as! NSString).doubleValue))
                
                let url: URL! = URL(string: mvinfo.thumbnail!)
                let imageData = try! Data(contentsOf: url)
                mvinfo.thumbnailImage = UIImage(data: imageData)
                
                self.list.append(mvinfo)
            }
        } catch {
            print("error")
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        callMovieAPI()
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.list.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let row = self.list[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "ListCell", for: indexPath)
        as! MovieCell
        
        cell.title?.text = row.title
        cell.descreiption?.text = row.descreiption
        cell.opendate?.text = row.opendata
        cell.rating?.text = "\(row.ratitng ?? 0)"
        cell.thumbnail.image = row.thumbnailImage
        
        return cell
    }
    
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        NSLog("선택된 행은 \(indexPath.row) 번째 행입니다")
    }
    var page = 1
    
    @IBAction func more(_ sender: Any) {
        
        self.page += 1
        self.callMovieAPI()
        self.tableView.reloadData()
    }
    
    func getThumbnailImage(index : Int) -> UIImage {
        let mvinfo = self.list[index]
        if let savedImage = mvinfo.thumbnailImage {
            return savedImage
        } else {
            let url = NSURL(string: mvinfo.thumbnail!)
            let imageData = NSData(contentsOf: url! as URL)
            mvinfo.thumbnailImage = UIImage(data:imageData! as Data)
            return mvinfo.thumbnailImage!
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "segue_detail" {
            let path = self.tableView.indexPath(for: sender as! MovieCell)
            
            let detailVC = segue.destination as? DetailViewController
            detailVC?.mvinfo = self.list[path!.row]
        }
    }
}



