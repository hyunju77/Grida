//
//  MovieCell.swift
//  Movie
//
//  Created by swa on 2021/06/08.
//

import UIKit

class MovieCell: UITableViewCell {

    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var descreiption: UILabel!
    @IBOutlet weak var opendate: UILabel!
    @IBOutlet weak var rating: UILabel!
    @IBOutlet weak var thumbnail: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
