//
//  MovieInfo.swift
//  Movie
//
//  Created by swa on 2021/06/08.
//
import Foundation
import UIKit

class MovieInfo {
    init() {
    }
    
    var thumbnail : String?
    var title : String?
    var descreiption : String?
    var detail : String?
    var opendata : String?
    var ratitng : Float?
    var thumbnailImage : UIImage?
}
